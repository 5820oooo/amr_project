import os

from launch import LaunchDescription
from launch_ros.actions import Node

from ament_index_python.packages import get_package_share_directory


def generate_launch_description():

    # ==================================================
    # 找到安装后的参数文件
    # ==================================================
    #
    # 最终路径类似：
    #
    # install/amr_delivery_system/
    #     share/amr_delivery_system/
    #         config/amr_params.yaml
    # ==================================================

    params_file = os.path.join(
        get_package_share_directory("amr_delivery_system"),
        "config",
        "amr_params.yaml"
    )


    # ==================================================
    # AMR Simulator
    # ==================================================
    #
    # 相当于以前手动执行：
    #
    # ros2 run amr_delivery_system amr_simulator
    # ==================================================

    simulator = Node(
        package="amr_delivery_system",
        executable="amr_simulator",
        name="amr_simulator",
        output="screen"
    )


    # ==================================================
    # AMR Executor
    # ==================================================
    #
    # 相当于以前：
    #
    # ros2 run amr_delivery_system amr_executor
    #
    # 同时加载 YAML Parameters。
    # ==================================================

    executor = Node(
        package="amr_delivery_system",
        executable="amr_executor",
        name="amr_executor",
        output="screen",
        parameters=[params_file]
    )


    # ==================================================
    # 返回 LaunchDescription
    # ==================================================

    return LaunchDescription([
        simulator,
        executor
    ])
