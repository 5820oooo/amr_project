#include <chrono>
#include <cmath>
#include <memory>
#include <algorithm>
#include <functional>
#include <unordered_map>
#include <string>
#include <utility>
#include <thread>
#include <mutex>

#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"
#include "rcl_interfaces/msg/set_parameters_result.hpp"



#include "geometry_msgs/msg/twist.hpp"
#include "geometry_msgs/msg/pose2_d.hpp"

#include "amr_interfaces/action/delivery.hpp"
#include "amr_interfaces/srv/emergency_stop.hpp"
#include "amr_interfaces/srv/reset_fault.hpp"


using namespace std::chrono_literals;


// Delivery Action 类型别名
using Delivery =
    amr_interfaces::action::Delivery;


// Action Server 端的 GoalHandle 类型
using GoalHandleDelivery =
    rclcpp_action::ServerGoalHandle<Delivery>;

using EmergencyStop =
    amr_interfaces::srv::EmergencyStop;

using ResetFault =
    amr_interfaces::srv::ResetFault;

class AmrExecutor : public rclcpp::Node
{
public:

    AmrExecutor()
    : Node("amr_executor")
    {
        // ==================================================
        // 1. 声明 ROS2 Parameters
        // ==================================================
        //
        // declare_parameter：
        // 告诉 ROS2：
        // “我的节点拥有这些参数，并给出默认值。”
        //
        // 注意：
        // Parameter 和下面的 C++ 成员变量不是同一个东西。
        // 后面还需要 get_parameter() 把值读出来。
        // ==================================================

        this->declare_parameter(
            "max_speed",
            0.8);

        this->declare_parameter(
            "k_angle",
            2.0);

        this->declare_parameter(
            "max_angular",
            2.0);

        this->declare_parameter(
            "max_load",
            50.0);

        this->declare_parameter(
            "arrival_tolerance",
            0.15);

        this->declare_parameter(
            "loading_time",
            2.0);

        this->declare_parameter(
            "unloading_time",
            2.0);

        this->declare_parameter(
            "task_timeout",
            60.0);



        // ==================================================
        // 2. 读取 Parameters 到 C++ 成员变量
        // ==================================================
        //
        // ROS2 Parameter：
        //      max_speed
        //          ↓
        // get_parameter()
        //          ↓
        // C++：
        //      max_speed_
        //
        // 后面的控制代码真正使用的是 max_speed_。
        // ==================================================

        this->get_parameter(
            "max_speed",
            max_speed_);

        this->get_parameter(
            "k_angle",
            k_angle_);

        this->get_parameter(
            "max_angular",
            max_angular_);

        this->get_parameter(
            "max_load",
            max_load_);

        this->get_parameter(
            "arrival_tolerance",
            arrival_tolerance_);

        this->get_parameter(
            "loading_time",
            loading_time_);

        this->get_parameter(
            "unloading_time",
            unloading_time_);

        this->get_parameter(
            "task_timeout",
            task_timeout_);

            // ==================================================
            // 3. 注册动态 Parameter Callback
            // ==================================================

            param_callback_handle_ =
                this->add_on_set_parameters_callback(
                    std::bind(
                        &AmrExecutor::parameters_callback,
                        this,
                        std::placeholders::_1));

        // ==================================================
        // 3. 工厂站点表
        // ==================================================
        //
        // 业务层使用站点名称：
        //
        // WAREHOUSE_A
        // LINE_01
        //
        // Executor 再把站点名称转换为具体坐标。
        // ==================================================

        stations_["CHARGING"] =
            {1.0, 1.0};

        stations_["WAREHOUSE_A"] =
            {2.0, 8.0};

        stations_["LINE_01"] =
            {9.0, 8.0};

        stations_["LINE_02"] =
            {9.0, 2.0};



        // ==================================================
        // 4. Pose Subscriber
        // ==================================================
        //
        // Simulator 不断发布机器人当前位置：
        //
        // /amr/pose
        //
        // Executor 订阅这个 Topic，
        // 得到 current_x / current_y / current_theta。
        // ==================================================

        pose_sub_ =
            this->create_subscription<
                geometry_msgs::msg::Pose2D>(
                "/amr/pose",
                10,
                std::bind(
                    &AmrExecutor::pose_callback,
                    this,
                    std::placeholders::_1));



        // ==================================================
        // 5. cmd_vel Publisher
        // ==================================================
        //
        // Executor 根据当前位置和目标位置，
        // 计算速度命令：
        //
        // /amr/cmd_vel
        //
        // Simulator 接收速度以后，
        // 真正更新机器人位置。
        // ==================================================

        cmd_pub_ =
            this->create_publisher<
                geometry_msgs::msg::Twist>(
                "/amr/cmd_vel",
                10);



        // ==================================================
        // 6. 50ms 运动控制循环
        // ==================================================
        //
        // 每 50ms：
        //
        // 当前 Pose
        //      ↓
        // 目标坐标
        //      ↓
        // 计算距离、方向
        //      ↓
        // 发布 cmd_vel
        // ==================================================

        timer_ =
            this->create_wall_timer(
                50ms,
                std::bind(
                    &AmrExecutor::control_loop,
                    this));



        // ==================================================
        // 7. Delivery Action Server
        // ==================================================
        //
        // Dispatcher
        //      │
        //      │ Delivery Action
        //      ▼
        // Executor
        //
        // 三个回调：
        //
        // handle_goal
        //      → 接不接任务
        //
        // handle_cancel
        //      → 允不允许取消
        //
        // handle_accepted
        //      → 接单以后真正开始执行
        // ==================================================

        delivery_server_ =
            rclcpp_action::create_server<Delivery>(
                this,
                "delivery",

                std::bind(
                    &AmrExecutor::handle_goal,
                    this,
                    std::placeholders::_1,
                    std::placeholders::_2),

                std::bind(
                    &AmrExecutor::handle_cancel,
                    this,
                    std::placeholders::_1),

                std::bind(
                    &AmrExecutor::handle_accepted,
                    this,
                    std::placeholders::_1));

        // ==================================================
        // Emergency Stop Service
        // ==================================================

        emergency_srv_ =
            this->create_service<EmergencyStop>(
                "emergency_stop",

                std::bind(
                    &AmrExecutor::emergency_callback,
                    this,
                    std::placeholders::_1,
                    std::placeholders::_2));

        // ==================================================
        // Reset Fault Service
        // ==================================================

        reset_fault_srv_ =
            this->create_service<ResetFault>(
                "reset_fault",

                std::bind(
                    &AmrExecutor::reset_fault_callback,
                    this,
                    std::placeholders::_1,
                    std::placeholders::_2));




        RCLCPP_INFO(
            this->get_logger(),
            "AMR Executor started");

        RCLCPP_INFO(
            this->get_logger(),
            "Parameters: max_speed=%.2f, max_load=%.2f, "
            "arrival_tolerance=%.2f",
            max_speed_,
            max_load_,
            arrival_tolerance_);
    }



private:

    // ==================================================
    // 机器人业务状态
    // ==================================================

    enum class RobotState
    {
        IDLE,

        TO_PICKUP,

        LOADING,

        TO_TARGET,

        UNLOADING,

        COMPLETED,

        CANCELED,

        FAULT
    };


    RobotState state_ =
        RobotState::IDLE;



    // ==================================================
    // ROS 对象
    // ==================================================

    // 订阅机器人当前位置
    rclcpp::Subscription<
        geometry_msgs::msg::Pose2D>::
        SharedPtr pose_sub_;


    // 发布机器人速度
    rclcpp::Publisher<
        geometry_msgs::msg::Twist>::
        SharedPtr cmd_pub_;


    // 运动控制 Timer
    rclcpp::TimerBase::
        SharedPtr timer_;

    // Parameter 动态修改回调句柄
    rclcpp::node_interfaces::
        OnSetParametersCallbackHandle::
        SharedPtr param_callback_handle_;


    // Delivery Action Server
    rclcpp_action::Server<
        Delivery>::
        SharedPtr delivery_server_;

    // Emergency Stop Service
    rclcpp::Service<
        EmergencyStop>::
        SharedPtr emergency_srv_;

    // 故障复位 Service
    rclcpp::Service<
        ResetFault>::
        SharedPtr reset_fault_srv_;




    // ==================================================
    // 工厂站点表
    // ==================================================
    //
    // string：
    //      WAREHOUSE_A
    //
    // pair：
    //      x, y
    // ==================================================

    std::unordered_map<
        std::string,
        std::pair<double, double>
    > stations_;



    // ==================================================
    // 共享数据
    // ==================================================
    //
    // Pose Callback、
    // Timer、
    // Action 执行线程
    //
    // 都可能访问下面的数据，
    // 因此使用 mutex 做基本保护。
    // ==================================================

    std::mutex data_mutex_;


    // 当前机器人位置
    double current_x_ = 0.0;
    double current_y_ = 0.0;
    double current_theta_ = 0.0;


    // 是否已经收到 Simulator 发布的 Pose
    bool pose_received_ = false;


    // 当前导航目标
    double target_x_ = 0.0;
    double target_y_ = 0.0;


    // 是否正在导航
    bool navigation_active_ = false;


    // 是否已经到达目标
    bool target_reached_ = false;


    // 当前是否有配送任务
    bool task_active_ = false;

    // 当前是否处于故障状态
    bool fault_active_ = false;

    // ==================================================
    // Parameters 对应的业务成员变量
    // ==================================================
    //
    // ROS2 Parameter
    //      ↓
    // get_parameter()
    //      ↓
    // 这些成员变量
    //      ↓
    // 真正影响业务行为
    // ==================================================


    // 最大线速度
    double max_speed_;


    // 角度控制比例系数
    double k_angle_;


    // 最大角速度
    double max_angular_;


    // 最大载重量
    double max_load_;


    // 到达目标的距离容差
    double arrival_tolerance_;


    // 模拟装货时间
    double loading_time_;


    // 模拟卸货时间
    double unloading_time_;


    // 整个任务允许的最长执行时间
    //
    // 当前 M7 先读取，
    // 后面 M9.5 再真正加入超时判断。
    double task_timeout_;

    // ==================================================
    // Timeout 状态
    // ==================================================

    // 当前任务开始时间
    std::chrono::steady_clock::time_point
        task_start_time_;

    // 当前任务是否因为超时终止
    bool timeout_active_ = false;


    // ==================================================
    // Parameter 动态修改回调
    // ==================================================

    rcl_interfaces::msg::SetParametersResult
    parameters_callback(
        const std::vector<
            rclcpp::Parameter> &params)
{
    // 默认认为修改成功
    rcl_interfaces::msg::
        SetParametersResult result;

    result.successful = true;


    // 一次请求可能修改多个 Parameter，
    // 所以逐个检查。
    for (const auto &param : params)
    {
        // ==================================================
        // max_speed
        // ==================================================

        if (param.get_name() == "max_speed")
        {
            double value =
                param.as_double();


            // 最大速度必须在合理范围内
            if (
                value <= 0.0
                ||
                value > 3.0)
            {
                result.successful =
                    false;

                result.reason =
                    "max_speed must be in (0, 3]";

                return result;
            }


            max_speed_ =
                value;


            RCLCPP_INFO(
                this->get_logger(),
                "Parameter updated: max_speed = %.2f",
                max_speed_);
        }


        // ==================================================
        // k_angle
        // ==================================================

        else if (param.get_name() == "k_angle")
        {
            double value =
                param.as_double();


            if (
                value <= 0.0
                ||
                value > 10.0)
            {
                result.successful =
                    false;

                result.reason =
                    "k_angle must be in (0, 10]";

                return result;
            }


            k_angle_ =
                value;


            RCLCPP_INFO(
                this->get_logger(),
                "Parameter updated: k_angle = %.2f",
                k_angle_);
        }


        // ==================================================
        // max_angular
        // ==================================================

        else if (
            param.get_name()
            ==
            "max_angular")
        {
            double value =
                param.as_double();


            if (
                value <= 0.0
                ||
                value > 10.0)
            {
                result.successful =
                    false;

                result.reason =
                    "max_angular must be in (0, 10]";

                return result;
            }


            max_angular_ =
                value;


            RCLCPP_INFO(
                this->get_logger(),
                "Parameter updated: max_angular = %.2f",
                max_angular_);
        }


        // ==================================================
        // max_load
        // ==================================================

        else if (
            param.get_name()
            ==
            "max_load")
        {
            double value =
                param.as_double();


            if (
                value <= 0.0
                ||
                value > 500.0)
            {
                result.successful =
                    false;

                result.reason =
                    "max_load must be in (0, 500]";

                return result;
            }


            max_load_ =
                value;


            RCLCPP_INFO(
                this->get_logger(),
                "Parameter updated: max_load = %.2f",
                max_load_);
        }


        // ==================================================
        // arrival_tolerance
        // ==================================================

        else if (
            param.get_name()
            ==
            "arrival_tolerance")
        {
            double value =
                param.as_double();


            if (
                value <= 0.0
                ||
                value > 2.0)
            {
                result.successful =
                    false;

                result.reason =
                    "arrival_tolerance must be in (0, 2]";

                return result;
            }


            arrival_tolerance_ =
                value;


            RCLCPP_INFO(
                this->get_logger(),
                "Parameter updated: arrival_tolerance = %.2f",
                arrival_tolerance_);
        }


        // ==================================================
        // loading_time
        // ==================================================

        else if (
            param.get_name()
            ==
            "loading_time")
        {
            double value =
                param.as_double();


            if (
                value < 0.0
                ||
                value > 60.0)
            {
                result.successful =
                    false;

                result.reason =
                    "loading_time must be in [0, 60]";

                return result;
            }


            loading_time_ =
                value;


            RCLCPP_INFO(
                this->get_logger(),
                "Parameter updated: loading_time = %.2f",
                loading_time_);
        }


        // ==================================================
        // unloading_time
        // ==================================================

        else if (
            param.get_name()
            ==
            "unloading_time")
        {
            double value =
                param.as_double();


            if (
                value < 0.0
                ||
                value > 60.0)
            {
                result.successful =
                    false;

                result.reason =
                    "unloading_time must be in [0, 60]";

                return result;
            }


            unloading_time_ =
                value;


            RCLCPP_INFO(
                this->get_logger(),
                "Parameter updated: unloading_time = %.2f",
                unloading_time_);
        }


        // ==================================================
        // task_timeout
        // ==================================================

        else if (
            param.get_name()
            ==
            "task_timeout")
        {
            double value =
                param.as_double();


            if (
                value <= 0.0
                ||
                value > 3600.0)
            {
                result.successful =
                    false;

                result.reason =
                    "task_timeout must be in (0, 3600]";

                return result;
            }


            task_timeout_ =
                value;


            RCLCPP_INFO(
                this->get_logger(),
                "Parameter updated: task_timeout = %.2f",
                task_timeout_);
        }
    }


    return result;
}

    // ==================================================
    // Pose Callback
    // ==================================================
    //
    // Simulator：
    //
    // /amr/pose
    //      ↓
    // pose_callback()
    //      ↓
    // 更新机器人当前位置
    // ==================================================

    void pose_callback(
        const geometry_msgs::msg::Pose2D::
            SharedPtr msg)
    {
        std::lock_guard<std::mutex>
            lock(data_mutex_);


        current_x_ =
            msg->x;

        current_y_ =
            msg->y;

        current_theta_ =
            msg->theta;


        pose_received_ =
            true;
    }



    // ==================================================
    // Action：判断是否接受 Goal
    // ==================================================

    rclcpp_action::GoalResponse
    handle_goal(
        const rclcpp_action::GoalUUID &uuid,
        std::shared_ptr<
            const Delivery::Goal> goal)
    {
        // 当前没有使用 UUID
        (void)uuid;


        RCLCPP_INFO(
            this->get_logger(),

            "Goal: task=%s, pickup=%s, "
            "target=%s, cargo=%.1f kg",

            goal->task_id.c_str(),

            goal->pickup_station.c_str(),

            goal->target_station.c_str(),

            goal->cargo_weight);


        
            // ==================================================
        // 系统状态检查
        // ==================================================

        {
            std::lock_guard<std::mutex>
                lock(data_mutex_);


            // 当前处于故障状态
            if (fault_active_)
            {
                RCLCPP_WARN(
                    this->get_logger(),
                    "Reject: robot is in FAULT state");


                return
                    rclcpp_action::
                    GoalResponse::REJECT;
            }


            // 当前已经有任务
            if (task_active_)
            {
                RCLCPP_WARN(
                    this->get_logger(),
                    "Reject: another task is running");


                return
                    rclcpp_action::
                    GoalResponse::REJECT;
            }
        }


        // ==================================================
        // 2. 检查取货站
        // ==================================================

        if (
            stations_.find(
                goal->pickup_station)
            ==
            stations_.end())
        {
            RCLCPP_WARN(
                this->get_logger(),
                "Reject: unknown pickup station");


            return
                rclcpp_action::
                GoalResponse::REJECT;
        }



        // ==================================================
        // 3. 检查目标站
        // ==================================================

        if (
            stations_.find(
                goal->target_station)
            ==
            stations_.end())
        {
            RCLCPP_WARN(
                this->get_logger(),
                "Reject: unknown target station");


            return
                rclcpp_action::
                GoalResponse::REJECT;
        }



        // ==================================================
        // 4. 起点终点不能相同
        // ==================================================

        if (
            goal->pickup_station
            ==
            goal->target_station)
        {
            RCLCPP_WARN(
                this->get_logger(),
                "Reject: pickup and target are the same");


            return
                rclcpp_action::
                GoalResponse::REJECT;
        }



        // ==================================================
        // 5. 重量必须 > 0
        // ==================================================

        if (goal->cargo_weight <= 0.0)
        {
            RCLCPP_WARN(
                this->get_logger(),
                "Reject: invalid cargo weight");


            return
                rclcpp_action::
                GoalResponse::REJECT;
        }



        // ==================================================
        // 6. 超载检查
        // ==================================================
        //
        // 这里已经不再写死 50kg。
        //
        // 使用 Parameter：
        //
        // max_load
        //      ↓
        // max_load_
        //      ↓
        // Goal ACCEPT / REJECT
        // ==================================================

        if (goal->cargo_weight > max_load_)
        {
            RCLCPP_WARN(
                this->get_logger(),

                "Reject: cargo overweight "
                "(%.1f > %.1f)",

                goal->cargo_weight,
                max_load_);


            return
                rclcpp_action::
                GoalResponse::REJECT;
        }



        // Goal 检查通过，
        // 标记机器人正在执行任务。
        {
            std::lock_guard<std::mutex>
                lock(data_mutex_);


            task_active_ =
                true;
        }


        return
            rclcpp_action::
            GoalResponse::
                ACCEPT_AND_EXECUTE;
    }



    // ==================================================
    // Action：是否允许取消
    // ==================================================

    rclcpp_action::CancelResponse
    handle_cancel(
        const std::shared_ptr<
            GoalHandleDelivery> goal_handle)
    {
        (void)goal_handle;


        RCLCPP_INFO(
            this->get_logger(),
            "Cancel request received");


        //这里只代表：
        //
        // “允许取消”
        //
        // 真正停止机器人，
        // 还需要执行线程检查 is_canceling()。
        return
            rclcpp_action::
            CancelResponse::ACCEPT;
    }



    // ==================================================
    // Action：Goal 被接受
    // ==================================================

    void handle_accepted(
        const std::shared_ptr<
            GoalHandleDelivery> goal_handle)
    {
        // 配送任务可能持续几十秒，
        // 不能直接堵住 ROS2 回调线程。
        //
        // 所以新开线程执行 execute_delivery()。

        std::thread(
            &AmrExecutor::execute_delivery,
            this,
            goal_handle)
            .detach();
    }

    // ==================================================
    // Emergency Stop Service Callback
    // ==================================================

    void emergency_callback(
        const std::shared_ptr<
            EmergencyStop::Request> request,

        std::shared_ptr<
            EmergencyStop::Response> response)
    {
        // 1. 立即停车
        publish_stop();


        // 2. 修改系统状态
        {
            std::lock_guard<std::mutex>
                lock(data_mutex_);


            fault_active_ = true;

            state_ =
                RobotState::FAULT;

            navigation_active_ =
                false;

            target_reached_ =
                false;
        }


        // 3. 返回 Service Response
        response->success =
            true;

        response->message =
            "Emergency stop activated";


        // 4. 打印日志
        RCLCPP_ERROR(
            this->get_logger(),

            "[EMERGENCY] reason=%s",

            request->reason.c_str());
    }


    // ==================================================
    // Reset Fault Service Callback
    // ==================================================

    void reset_fault_callback(
        const std::shared_ptr<
            ResetFault::Request> request,

        std::shared_ptr<
            ResetFault::Response> response)
    {
        std::lock_guard<std::mutex>
            lock(data_mutex_);


        // ==================================================
        // 当前不是 FAULT
        // ==================================================
        //
        // 没有故障就没必要复位。
        // ==================================================

        if (!fault_active_)
        {
            response->success =
                false;

            response->message =
                "robot is not in FAULT state";


            RCLCPP_WARN(
                this->get_logger(),

                "[RESET] rejected: robot is not in FAULT state, "
                "operator=%s",

                request->operator_name.c_str());


            return;
        }


        // ==================================================
        // 清除故障状态
        // ==================================================

        fault_active_ =
            false;


        state_ =
            RobotState::IDLE;


        // 确保导航状态也恢复干净
        navigation_active_ =
            false;

        target_reached_ =
            false;

        task_active_ =
            false;


        // ==================================================
        // 返回成功
        // ==================================================

        response->success =
            true;

        response->message =
            "fault reset successfully";


        RCLCPP_INFO(
            this->get_logger(),

            "[RESET] fault cleared by operator=%s",

            request->operator_name.c_str());
    }






    // ==================================================
    // 真正执行配送任务
    // ==================================================

    void execute_delivery(
        const std::shared_ptr<
            GoalHandleDelivery> goal_handle)
    {
        // 取得 Dispatcher 发来的 Goal
        auto goal =
            goal_handle->get_goal();


        // 记录任务开始时间
        auto start_time =
            std::chrono::steady_clock::now();


        // 保存当前任务开始时间
        {
            std::lock_guard<std::mutex>
                lock(data_mutex_);

            task_start_time_ =
                start_time;

            timeout_active_ =
                false;
        }


        // 根据站点名称找到坐标
        auto pickup =
            stations_.at(
                goal->pickup_station);

        auto target =
            stations_.at(
                goal->target_station);



        // ==================================================
        // 1. 前往取货点
        // ==================================================

        {
            std::lock_guard<std::mutex>
                lock(data_mutex_);


            state_ =
                RobotState::TO_PICKUP;
        }


        RCLCPP_INFO(
            this->get_logger(),

            "[%s] Moving to pickup: %s",

            goal->task_id.c_str(),

            goal->pickup_station.c_str());



        if (!move_to(
                pickup.first,
                pickup.second,
                0.0,
                35.0,
                goal_handle))
        {
            bool fault;
            bool timeout;

            {
                std::lock_guard<std::mutex>
                    lock(data_mutex_);

                fault =
                    fault_active_;

                timeout =
                    timeout_active_;
            }


            // Emergency Stop
            if (fault)
            {
                finish_fault(
                    goal_handle);
            }

            // Task Timeout
            else if (timeout)
            {
                finish_timeout(
                    goal_handle);
            }

            // Client Cancel
            else
            {
                finish_canceled(
                    goal_handle);
            }


            return;
        }



        // ==================================================
        // 2. 装货
        // ==================================================

        {
            std::lock_guard<std::mutex>
                lock(data_mutex_);


            state_ =
                RobotState::LOADING;
        }


        publish_feedback(
            goal_handle,
            40.0);


        RCLCPP_INFO(
            this->get_logger(),

            "[%s] Loading cargo (%.1f s)",

            goal->task_id.c_str(),

            loading_time_);



        // 以前这里写死：
        //
        // sleep_for(1s);
        //
        // 现在使用 Parameter：
        //
        // loading_time
        //      ↓
        // loading_time_
        //      ↓
        // 实际装货等待时间

        std::this_thread::sleep_for(
            std::chrono::duration<double>(
                loading_time_));



        // 装货期间也可能收到取消请求
        if (goal_handle->is_canceling())
        {
            finish_canceled(
                goal_handle);

            return;
        }



        // ==================================================
        // 3. 前往目标点
        // ==================================================

        {
            std::lock_guard<std::mutex>
                lock(data_mutex_);


            state_ =
                RobotState::TO_TARGET;
        }


        RCLCPP_INFO(
            this->get_logger(),

            "[%s] Moving to target: %s",

            goal->task_id.c_str(),

            goal->target_station.c_str());



        if (!move_to(
                target.first,
                target.second,
                45.0,
                90.0,
                goal_handle))
        {
            bool fault;
            bool timeout;

            {
                std::lock_guard<std::mutex>
                    lock(data_mutex_);

                fault =
                    fault_active_;

                timeout =
                    timeout_active_;
            }


            if (fault)
            {
                finish_fault(
                    goal_handle);
            }
            else if (timeout)
            {
                finish_timeout(
                    goal_handle);
            }
            else
            {
                finish_canceled(
                    goal_handle);
            }


            return;
        }



        // ==================================================
        // 4. 卸货
        // ==================================================

        {
            std::lock_guard<std::mutex>
                lock(data_mutex_);


            state_ =
                RobotState::UNLOADING;
        }


        publish_feedback(
            goal_handle,
            95.0);


        RCLCPP_INFO(
            this->get_logger(),

            "[%s] Unloading cargo (%.1f s)",

            goal->task_id.c_str(),

            unloading_time_);



        // 使用 unloading_time Parameter
        std::this_thread::sleep_for(
            std::chrono::duration<double>(
                unloading_time_));
        if (goal_handle->is_canceling())
        {
            finish_canceled(
                goal_handle);

            return;
        }


        if (check_task_timeout())
        {
            finish_timeout(
                goal_handle);

            return;
        }


        // 卸货期间同样检查取消
        if (goal_handle->is_canceling())
        {
            finish_canceled(
                goal_handle);

            return;
        }

        if (check_task_timeout())
        {
            finish_timeout(
                goal_handle);

            return;
        }

        // ==================================================
        // 5. 配送完成
        // ==================================================

        {
            std::lock_guard<std::mutex>
                lock(data_mutex_);


            state_ =
                RobotState::COMPLETED;
        }


        publish_feedback(
            goal_handle,
            100.0);



        // 计算任务耗时
        auto end_time =
            std::chrono::
                steady_clock::now();


        double total_time =
            std::chrono::duration<double>(
                end_time - start_time)
                .count();



        // 创建 Result
        auto result =
            std::make_shared<
                Delivery::Result>();


        result->success =
            true;

        result->message =
            "delivery completed";

        result->total_time =
            total_time;



        // 通知 Action Client：
        //
        // 任务成功完成
        goal_handle->succeed(
            result);



        RCLCPP_INFO(
            this->get_logger(),

            "[%s] Delivery completed in %.2f s",

            goal->task_id.c_str(),

            total_time);



        // 任务结束后回到 IDLE
        {
            std::lock_guard<std::mutex>
                lock(data_mutex_);


            state_ =
                RobotState::IDLE;


            task_active_ =
                false;
        }
    }



    // ==================================================
    // 移动到指定位置
    // ==================================================

    bool move_to(
        double target_x,
        double target_y,

        double progress_start,
        double progress_end,

        const std::shared_ptr<
            GoalHandleDelivery> &goal_handle)
    {
        double start_distance =
            1.0;


        // 设置新的导航目标
        {
            std::lock_guard<std::mutex>
                lock(data_mutex_);


            target_x_ =
                target_x;

            target_y_ =
                target_y;


            navigation_active_ =
                true;

            target_reached_ =
                false;



            double dx =
                target_x_
                -
                current_x_;


            double dy =
                target_y_
                -
                current_y_;


            start_distance =
                std::sqrt(
                    dx * dx
                    +
                    dy * dy);
        }



        // 等待 control_loop()
        // 真正把机器人移动到目标位置。
        while (rclcpp::ok())
        {
            // ==========================================
            // 检查 Cancel
            // ==========================================

            if (goal_handle->is_canceling())
            {
                publish_stop();


                std::lock_guard<std::mutex>
                    lock(data_mutex_);


                navigation_active_ =
                    false;


                return false;
            }

            // 2. Emergency Fault
            {
                std::lock_guard<std::mutex>
                    lock(data_mutex_);

                if (fault_active_)
                {
                    navigation_active_ =
                        false;

                    return false;
                }
            }
            // ==================================================
            // 3. Task Timeout
            // ==================================================

            if (check_task_timeout())
            {
                return false;
            }


            double x;
            double y;

            bool reached;


            {
                std::lock_guard<std::mutex>
                    lock(data_mutex_);


                x =
                    current_x_;

                y =
                    current_y_;

                reached =
                    target_reached_;
            }



            // ==========================================
            // 已到达目标
            // ==========================================

            if (reached)
            {
                publish_feedback(
                    goal_handle,
                    progress_end);


                return true;
            }



            // ==========================================
            // 根据距离估算任务进度
            // ==========================================

            double dx =
                target_x - x;


            double dy =
                target_y - y;


            double distance =
                std::sqrt(
                    dx * dx
                    +
                    dy * dy);


            double ratio =
                1.0
                -
                distance
                /
                std::max(
                    start_distance,
                    0.001);


            ratio =
                std::clamp(
                    ratio,
                    0.0,
                    1.0);


            double progress =
                progress_start
                +
                ratio
                *
                (
                    progress_end
                    -
                    progress_start
                );


            publish_feedback(
                goal_handle,
                progress);


            // Feedback 每 100ms 更新一次
            std::this_thread::sleep_for(
                100ms);
        }


        return false;
    }



    // ==================================================
    // 发布 Action Feedback
    // ==================================================

    void publish_feedback(
        const std::shared_ptr<
            GoalHandleDelivery> &goal_handle,

        double progress)
    {
        auto feedback =
            std::make_shared<
                Delivery::Feedback>();


        {
            std::lock_guard<std::mutex>
                lock(data_mutex_);


            feedback->state =
                state_to_string(
                    state_);


            feedback->progress =
                static_cast<float>(
                    progress);


            feedback->current_x =
                static_cast<float>(
                    current_x_);


            feedback->current_y =
                static_cast<float>(
                    current_y_);
        }


        goal_handle->publish_feedback(
            feedback);
    }



    // ==================================================
    // 完成取消流程
    // ==================================================

    void finish_canceled(
        const std::shared_ptr<
            GoalHandleDelivery> &goal_handle)
    {
        // 先停车
        publish_stop();


        {
            std::lock_guard<std::mutex>
                lock(data_mutex_);


            state_ =
                RobotState::CANCELED;


            navigation_active_ =
                false;
        }



        auto result =
            std::make_shared<
                Delivery::Result>();


        result->success =
            false;


        result->message =
            "delivery canceled";


        result->total_time =
            0.0;



        goal_handle->canceled(
            result);



        // Cancel 结束以后恢复 IDLE
        {
            std::lock_guard<std::mutex>
                lock(data_mutex_);


            state_ =
                RobotState::IDLE;


            task_active_ =
                false;
        }
    }

    // ==================================================
    // Emergency Fault：终止当前 Action
    // ==================================================

    void finish_fault(
        const std::shared_ptr<
            GoalHandleDelivery> &goal_handle)
    {
        publish_stop();


        auto result =
            std::make_shared<
                Delivery::Result>();


        result->success =
            false;

        result->message =
            "delivery aborted by emergency stop";

        result->total_time =
            0.0;


        // Action 异常终止
        goal_handle->abort(
            result);


        // 注意：
        // FAULT 状态不能自动回 IDLE。
        //
        // 必须等下一节 ResetFault
        // 才允许恢复。
        {
            std::lock_guard<std::mutex>
                lock(data_mutex_);


            state_ =
                RobotState::FAULT;

            fault_active_ =
                true;

            navigation_active_ =
                false;

            task_active_ =
                false;
        }


        RCLCPP_ERROR(
            this->get_logger(),
            "Delivery aborted because of emergency stop");
    }


    // ==================================================
    // Timeout：终止当前 Action
    // ==================================================

    void finish_timeout(
        const std::shared_ptr<
            GoalHandleDelivery> &goal_handle)
    {
        // 先确保机器人停车
        publish_stop();


        // 计算实际执行时间
        auto now =
            std::chrono::steady_clock::now();

        double elapsed =
            std::chrono::duration<double>(
                now - task_start_time_)
                .count();


        // 创建 Result
        auto result =
            std::make_shared<
                Delivery::Result>();


        result->success =
            false;

        result->message =
            "task timeout";

        result->total_time =
            elapsed;


        // Timeout 属于异常终止，
        // 所以使用 abort，而不是 canceled。
        goal_handle->abort(
            result);


        RCLCPP_ERROR(
            this->get_logger(),
            "Delivery aborted: task timeout after %.2f s",
            elapsed);


        // ==================================================
        // Timeout 不进入 FAULT
        //
        // 任务结束后恢复 IDLE，
        // 允许下一张任务继续执行。
        // ==================================================

        {
            std::lock_guard<std::mutex>
                lock(data_mutex_);

            state_ =
                RobotState::IDLE;

            navigation_active_ =
                false;

            target_reached_ =
                false;

            task_active_ =
                false;

            timeout_active_ =
                false;
        }
    }


    // ==================================================
    // 50ms 运动控制循环
    // ==================================================
    //
    // 这里是真正产生 cmd_vel 的地方。
    //
    // Parameter 已经真正接入：
    //
    // max_speed_
    // k_angle_
    // max_angular_
    // arrival_tolerance_
    // ==================================================

    void control_loop()
    {
        double current_x;
        double current_y;
        double current_theta;


        double target_x;
        double target_y;



        {
            std::lock_guard<std::mutex>
                lock(data_mutex_);


            // 没收到 Pose 或当前没有导航任务，
            // 就什么也不做。
            if (
                !pose_received_
                ||
                !navigation_active_)
            {
                return;
            }


            current_x =
                current_x_;

            current_y =
                current_y_;

            current_theta =
                current_theta_;


            target_x =
                target_x_;

            target_y =
                target_y_;
        }



        // 计算目标相对于当前机器人的位置差
        double dx =
            target_x
            -
            current_x;


        double dy =
            target_y
            -
            current_y;


        // 欧氏距离
        double distance =
            std::sqrt(
                dx * dx
                +
                dy * dy);



        // ==================================================
        // 到达目标判断
        // ==================================================
        //
        // 原来：
        //
        // distance < 0.15
        //
        // 现在：
        //
        // distance < arrival_tolerance_
        // ==================================================

        if (distance < arrival_tolerance_)
        {
            publish_stop();


            std::lock_guard<std::mutex>
                lock(data_mutex_);


            navigation_active_ =
                false;


            target_reached_ =
                true;


            return;
        }



        // ==================================================
        // 计算目标方向
        // ==================================================

        double target_angle =
            std::atan2(
                dy,
                dx);



        // 当前朝向与目标方向之间的误差
        double angle_error =
            normalize_angle(
                target_angle
                -
                current_theta);



        // ==================================================
        // 角速度控制
        // ==================================================
        //
        // angular = Kp × angle_error
        //
        // k_angle_ 来自 ROS2 Parameter。
        // ==================================================

        double angular =
            k_angle_
            *
            angle_error;



        // 角速度限幅
        angular =
            std::clamp(
                angular,

                -max_angular_,

                max_angular_);



        // ==================================================
        // 线速度
        // ==================================================
        //
        // max_speed_
        // 已经来自 ROS2 Parameter。
        // ==================================================

        double linear =
            max_speed_;



        // ==================================================
        // 偏差太大时，先转向
        // ==================================================
        //
        // 避免机器人方向都没对准，
        // 就一边横冲一边转向。
        // ==================================================

        if (
            std::abs(
                angle_error)
            >
            0.8)
        {
            linear =
                0.0;
        }



        // ==================================================
        // 发布 Twist
        // ==================================================

        geometry_msgs::msg::Twist
            cmd;


        cmd.linear.x =
            linear;


        cmd.angular.z =
            angular;


        cmd_pub_->publish(
            cmd);
    }



    // ==================================================
    // 停车
    // ==================================================

    void publish_stop()
    {
        geometry_msgs::msg::Twist
            cmd;


        cmd.linear.x =
            0.0;


        cmd.angular.z =
            0.0;


        cmd_pub_->publish(
            cmd);
    }



    // ==================================================
    // RobotState → string
    // ==================================================
    //
    // 用于 Action Feedback。
    // ==================================================

    std::string state_to_string(
        RobotState state)
    {
        switch (state)
        {
            case RobotState::IDLE:

                return "IDLE";


            case RobotState::TO_PICKUP:

                return "TO_PICKUP";


            case RobotState::LOADING:

                return "LOADING";


            case RobotState::TO_TARGET:

                return "TO_TARGET";


            case RobotState::UNLOADING:

                return "UNLOADING";


            case RobotState::COMPLETED:

                return "COMPLETED";


            case RobotState::CANCELED:

                return "CANCELED";


            case RobotState::FAULT:

                return "FAULT";
        }


        return "UNKNOWN";
    }

    // ==================================================
    // 检查当前任务是否超时
    // ==================================================

    bool check_task_timeout()
    {
        // 当前时间
        auto now =
            std::chrono::steady_clock::now();


        // 已执行时间
        double elapsed =
            std::chrono::duration<double>(
                now - task_start_time_)
                .count();


        // 未超时
        if (elapsed <= task_timeout_)
        {
            return false;
        }


        // ==================================================
        // 已经超时
        // ==================================================

        publish_stop();


        {
            std::lock_guard<std::mutex>
                lock(data_mutex_);

            timeout_active_ =
                true;

            navigation_active_ =
                false;
        }


        RCLCPP_ERROR(
            this->get_logger(),
            "Task timeout: elapsed=%.2f s, limit=%.2f s",
            elapsed,
            task_timeout_);


        return true;
    }    



    // ==================================================
    // 角度归一化
    // ==================================================
    //
    // 将任意角度限制到：
    //
    // [-π, π]
    //
    // 避免机器人选择错误的旋转方向。
    // ==================================================

    double normalize_angle(
        double angle)
    {
        while (angle > M_PI)
        {
            angle -=
                2.0 * M_PI;
        }


        while (angle < -M_PI)
        {
            angle +=
                2.0 * M_PI;
        }


        return angle;
    }
};



int main(
    int argc,
    char **argv)
{
    // 初始化 ROS2
    rclcpp::init(
        argc,
        argv);


    // 创建 AmrExecutor 并进入 ROS2 事件循环
    rclcpp::spin(
        std::make_shared<
            AmrExecutor>());


    // 关闭 ROS2
    rclcpp::shutdown();


    return 0;
}