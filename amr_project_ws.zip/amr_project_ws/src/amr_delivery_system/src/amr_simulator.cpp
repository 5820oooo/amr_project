#include <chrono>
#include <cmath>
#include <memory>
#include <functional>

#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "geometry_msgs/msg/pose2_d.hpp"

using namespace std::chrono_literals;

// AMR 模拟器节点
class AmrSimulator : public rclcpp::Node
{
public:
    AmrSimulator()
    : Node("amr_simulator"),
      x_(1.0),
      y_(1.0),
      theta_(0.0)
    {
        // 发布 AMR 当前位姿
        pose_pub_ =
            this->create_publisher<geometry_msgs::msg::Pose2D>(
                "/amr/pose", 10);

        // 订阅速度指令
        cmd_sub_ =
            this->create_subscription<geometry_msgs::msg::Twist>(
                "/amr/cmd_vel",
                10,
                std::bind(
                    &AmrSimulator::cmd_callback,
                    this,
                    std::placeholders::_1));

        // 每 50ms 更新一次机器人位置
        timer_ =
            this->create_wall_timer(
                50ms,
                std::bind(&AmrSimulator::update, this));
    }

private:
    // 当前位姿
    double x_;
    double y_;
    double theta_;

    // 当前速度
    double linear_speed_ = 0.0;
    double angular_speed_ = 0.0;

    // ROS 2 通信对象
    rclcpp::Publisher<geometry_msgs::msg::Pose2D>::SharedPtr pose_pub_;
    rclcpp::Subscription<geometry_msgs::msg::Twist>::SharedPtr cmd_sub_;
    rclcpp::TimerBase::SharedPtr timer_;

    // 收到速度指令后调用
    void cmd_callback(
        const geometry_msgs::msg::Twist::SharedPtr msg)
    {
        linear_speed_ = msg->linear.x;
        angular_speed_ = msg->angular.z;
    }

    // 根据速度更新机器人位姿
    void update()
    {
        constexpr double dt = 0.05;

        x_ += linear_speed_ * std::cos(theta_) * dt;
        y_ += linear_speed_ * std::sin(theta_) * dt;
        theta_ += angular_speed_ * dt;

        geometry_msgs::msg::Pose2D pose;
        pose.x = x_;
        pose.y = y_;
        pose.theta = theta_;

        pose_pub_->publish(pose);
    }
};

int main(int argc, char **argv)
{
    // 初始化 ROS 2
    rclcpp::init(argc, argv);

    // 创建节点并持续处理回调
    rclcpp::spin(
        std::make_shared<AmrSimulator>());

    // 关闭 ROS 2
    rclcpp::shutdown();

    return 0;
}