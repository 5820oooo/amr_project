#include <chrono>
#include <memory>
#include <functional>

#include "rclcpp/rclcpp.hpp"

#include "rcl_interfaces/srv/set_parameters.hpp"
#include "rcl_interfaces/msg/parameter.hpp"
#include "rcl_interfaces/msg/parameter_value.hpp"
#include "rcl_interfaces/msg/parameter_type.hpp"


using namespace std::chrono_literals;


using SetParameters =
    rcl_interfaces::srv::SetParameters;



class MaintenanceClient : public rclcpp::Node
{
public:

    MaintenanceClient()
    : Node("maintenance_client")
    {
        // ==================================================
        // 1. 创建 SetParameters Service Client
        // ==================================================

        client_ =
            this->create_client<SetParameters>(
                "/amr_executor/set_parameters");


        // ==================================================
        // 2. 等待 amr_executor 参数 Service
        // ==================================================

        if (!client_->wait_for_service(5s))
        {
            RCLCPP_ERROR(
                this->get_logger(),
                "SetParameters service not available");

            return;
        }


        RCLCPP_INFO(
            this->get_logger(),
            "Connected to amr_executor parameter service");


        // ==================================================
        // 3. 修改 max_speed
        // ==================================================

        set_max_speed();
    }


private:

    // SetParameters Service Client
    rclcpp::Client<SetParameters>::
        SharedPtr client_;



    // ==================================================
    // 构造并发送 Parameter 修改请求
    // ==================================================

    void set_max_speed()
    {
        // 创建 Service Request
        auto request =
            std::make_shared<
                SetParameters::Request>();


        // ==================================================
        // Parameter
        // ==================================================
        //
        // 表示：
        //
        // 参数名 = max_speed
        // ==================================================

        rcl_interfaces::msg::Parameter
            parameter;


        parameter.name =
            "max_speed";


        // ==================================================
        // ParameterValue
        // ==================================================
        //
        // ParameterValue 需要同时告诉 ROS2：
        //
        // 1. 数据类型
        // 2. 数据值
        // ==================================================

        rcl_interfaces::msg::ParameterValue
            value;


        value.type =
            rcl_interfaces::msg::ParameterType::
                PARAMETER_DOUBLE;


        value.double_value =
            1.0;


        // 把 value 放进 Parameter
        parameter.value =
            value;


        // ==================================================
        // 放入 SetParameters Request
        // ==================================================
        //
        // Request 中是 parameters 数组，
        // 因为一次请求可以修改多个 Parameter。
        // ==================================================

        request->parameters.push_back(
            parameter);


        RCLCPP_INFO(
            this->get_logger(),
            "Request: set max_speed = 1.0");


        // ==================================================
        // 4. 异步发送 Service Request
        // ==================================================

        client_->async_send_request(
            request,

            std::bind(
                &MaintenanceClient::
                    response_callback,

                this,

                std::placeholders::_1));
    }



    // ==================================================
    // 5. Service Response Callback
    // ==================================================

    void response_callback(
        rclcpp::Client<SetParameters>::
            SharedFuture future)
    {
        // 得到 Response
        auto response =
            future.get();


        // 理论上应该有一个结果
        if (response->results.empty())
        {
            RCLCPP_ERROR(
                this->get_logger(),
                "Empty SetParameters response");

            return;
        }


        // 我们只修改了一个 Parameter，
        // 所以读取 results[0]。
        const auto &result =
            response->results[0];


        if (result.successful)
        {
            RCLCPP_INFO(
                this->get_logger(),
                "max_speed updated successfully");
        }
        else
        {
            RCLCPP_ERROR(
                this->get_logger(),

                "Failed to update max_speed: %s",

                result.reason.c_str());
        }
    }
};



int main(int argc, char **argv)
{
    rclcpp::init(
        argc,
        argv);


    rclcpp::spin(
        std::make_shared<
            MaintenanceClient>());


    rclcpp::shutdown();


    return 0;
}