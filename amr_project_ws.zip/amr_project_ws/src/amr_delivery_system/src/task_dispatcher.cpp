/*
Dispatcher 的职责只有六件事

1 创建 Action Client
2 等待 Server
3 构造 Goal
4 发送 Goal
5 收 Feedback
6 收 Result
*/

#include <memory>
#include <chrono>
#include <functional>

#include "rclcpp/rclcpp.hpp"
#include "rclcpp_action/rclcpp_action.hpp"
#include "amr_interfaces/action/delivery.hpp"


using namespace std::chrono_literals;

using Delivery =
    amr_interfaces::action::Delivery;

using GoalHandleDelivery =
    rclcpp_action::ClientGoalHandle<Delivery>;


class TaskDispatcher : public rclcpp::Node
{
public:

    TaskDispatcher()
    : Node("task_dispatcher")
    {
        // ==================================================
        // Cancel 测试参数
        // ==================================================
        //
        // cancel_after = 0
        //      不自动取消
        //
        // cancel_after = 5
        //      Goal 接受 5 秒后自动取消
        // ==================================================

        this->declare_parameter(
            "cancel_after",
            0.0);

        this->get_parameter(
            "cancel_after",
            cancel_after_);        
        // 1. 创建 Action Client
        client_ =
            rclcpp_action::create_client<Delivery>(
                this,
                "delivery");


        // 2. 等待 Action Server
        if (!client_->wait_for_action_server(5s))
        {
            RCLCPP_ERROR(
                this->get_logger(),
                "Delivery Action Server not available");

            return;
        }


        RCLCPP_INFO(
            this->get_logger(),
            "Delivery Action Server connected");


        // Server 已连接，开始派单
        send_task();
    }


private:

    // Delivery Action Client
    rclcpp_action::Client<Delivery>::
        SharedPtr client_;

    // 自动取消时间
    //
    // <= 0 表示不取消
    double cancel_after_ = 0.0;


    // Cancel Timer
    rclcpp::TimerBase::SharedPtr
        cancel_timer_;
    // ==============================
    // 构造并发送配送任务
    // ==============================
    void send_task()
    {
        // 3. 构造 Goal
        Delivery::Goal goal;

        goal.task_id = "TASK_001";
        goal.pickup_station = "WAREHOUSE_A";
        goal.target_station = "LINE_01";
        goal.cargo_weight = 20.0f;


        RCLCPP_INFO(
            this->get_logger(),
            "Sending TASK_001: WAREHOUSE_A -> LINE_01");


        // 配置 Goal 发送后的三个回调
        rclcpp_action::Client<Delivery>::
            SendGoalOptions options;


        // Goal 是否被接受
        options.goal_response_callback =
            std::bind(
                &TaskDispatcher::goal_response_callback,
                this,
                std::placeholders::_1);


        // 执行过程中的 Feedback
        options.feedback_callback =
            std::bind(
                &TaskDispatcher::feedback_callback,
                this,
                std::placeholders::_1,
                std::placeholders::_2);


        // 最终 Result
        options.result_callback =
            std::bind(
                &TaskDispatcher::result_callback,
                this,
                std::placeholders::_1);


        // 4. 发送 Goal
        client_->async_send_goal(
            goal,
            options);
    }


    // ==============================
    // Goal Response
    // ==============================
    void goal_response_callback(
        const GoalHandleDelivery::SharedPtr &goal_handle)
    {
        // ==================================================
        // Goal 被拒绝
        // ==================================================

        if (!goal_handle)
        {
            RCLCPP_ERROR(
                this->get_logger(),
                "TASK_001 rejected");

            return;
        }


        // ==================================================
        // Goal 被接受
        // ==================================================

        RCLCPP_INFO(
            this->get_logger(),
            "TASK_001 accepted");


        // cancel_after <= 0
        // 表示正常执行，不自动 Cancel。
        if (cancel_after_ <= 0.0)
        {
            return;
        }


        // 把秒转换成 chrono duration
        auto cancel_delay =
            std::chrono::duration_cast<
                std::chrono::milliseconds>(
                    std::chrono::duration<double>(
                        cancel_after_));


        RCLCPP_WARN(
            this->get_logger(),
            "TASK_001 will be canceled after %.1f seconds",
            cancel_after_);


        // ==================================================
        // 创建 Cancel Timer
        // ==================================================

        cancel_timer_ =
            this->create_wall_timer(
                cancel_delay,

                [this, goal_handle]()
                {
                    // create_wall_timer 默认是周期 Timer。
                    //
                    // 我们这里只想 Cancel 一次，
                    // 所以第一次进入以后立即 cancel Timer。
                    cancel_timer_->cancel();


                    RCLCPP_WARN(
                        this->get_logger(),
                        "Canceling TASK_001...");


                    // 向 Action Server 发送 Cancel Request
                    client_->async_cancel_goal(
                        goal_handle);
                });
    }

    // ==============================
    // 5. Feedback
    // ==============================
    void feedback_callback(
        GoalHandleDelivery::SharedPtr,
        const std::shared_ptr<
            const Delivery::Feedback> feedback)
    {
        RCLCPP_INFO(
            this->get_logger(),
            "[TASK_001] state=%s progress=%.1f%% pose=(%.2f, %.2f)",
            feedback->state.c_str(),
            feedback->progress,
            feedback->current_x,
            feedback->current_y);
    }


    // ==============================
    // 6. Result
    // ==============================
    void result_callback(
        const GoalHandleDelivery::
            WrappedResult &result)
    {
        // 如果任务已经结束，就不再需要 Cancel Timer
        if (cancel_timer_)
        {
            cancel_timer_->cancel();
        }
        switch (result.code)
        {
            case rclcpp_action::ResultCode::SUCCEEDED:

                RCLCPP_INFO(
                    this->get_logger(),
                    "TASK_001 SUCCEEDED");

                break;


            case rclcpp_action::ResultCode::CANCELED:

                RCLCPP_WARN(
                    this->get_logger(),
                    "TASK_001 CANCELED");

                break;


            case rclcpp_action::ResultCode::ABORTED:

                RCLCPP_ERROR(
                    this->get_logger(),
                    "TASK_001 ABORTED");

                break;


            default:

                RCLCPP_ERROR(
                    this->get_logger(),
                    "Unknown result");

                return;
        }


        if (result.result)
        {
            RCLCPP_INFO(
                this->get_logger(),
                "success=%s message=%s total_time=%.2f",
                result.result->success
                    ? "true"
                    : "false",
                result.result->message.c_str(),
                result.result->total_time);
        }
    }
};


int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);


    rclcpp::spin(
        std::make_shared<TaskDispatcher>());


    rclcpp::shutdown();

    return 0;
}